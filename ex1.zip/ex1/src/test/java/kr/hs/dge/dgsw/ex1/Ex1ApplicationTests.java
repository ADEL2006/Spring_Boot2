package kr.hs.dge.dgsw.ex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
